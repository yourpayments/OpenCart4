<?php
namespace Opencart\Catalog\Model\Extension\Ypmn\Payment;

use Opencart\System\Engine\Model;

class Ypmn extends Model {

	public function getMethods(array $address): array
	{
		$title = $this->config->get('payment_ypmn_paymentname');
		$option_data['ypmn'] = [
				'code' => 'ypmn.ypmn',
				'name' => $title
			];

		$method_data = array(
			'code'       => 'ypmn',
			'option'     => $option_data,
			'name'      => $title,
			'sort_order' => $this->config->get('payment_ypmn_sort_order')
		);

		return $method_data;
	}

}