<?php
$_['text_item_delivery'] = 'Доставка';
$_['heading_title'] = 'Результат оплаты';
$_['text_success_message'] = '✅Оплата получена';
$_['text_product'] = 'Товар';
$_['text_error_currency'] = 'Оплата поддерживается только в рублях';