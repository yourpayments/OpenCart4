<?php
$_['text_item_delivery'] = 'Delivery';
$_['text_order_number'] = 'Order number ';
$_['heading_title'] = 'Payment result';
$_['text_success_message'] = '✅Success';
$_['text_error_currency'] = 'Unsupported currency';