<?php
namespace Opencart\Catalog\Controller\Extension\Ypmn\Payment;

require_once DIR_EXTENSION . 'ypmn/system/library/autoload.php';

use Opencart\System\Engine\Controller;
use Opencart\System\Library\Log;
use Ypmn\ApiRequest;
use Ypmn\Authorization;
use Ypmn\Billing;
use Ypmn\Client;
use Ypmn\Merchant;
use Ypmn\Payment;
use Ypmn\PaymentMethods;
use Ypmn\Product;

class Ypmn extends \Opencart\System\Engine\Controller
{

	private Log $log;
	private bool $logging;

	public function __construct($registry)
	{
		parent::__construct($registry);

		$this->log     = new Log('ypmn.log');
		$this->logging = $this->config->get('payment_ypmn_logging') === '1';
	}

	public function index()
	{
		$this->load->language('extension/ypmn/payment/ypmn');
		$data['action']         = $this->url->link('extension/ypmn/payment/ypmn.process_order', '', true);
		$data['button_confirm'] = $this->language->get('button_confirm');
		return $this->load->view('extension/ypmn/payment/ypmn', $data);
	}

	public function result()
	{
		$this->load->language('checkout/success');
		$this->load->language('extension/ypmn/payment/ypmn');
		$body = html_entity_decode($this->request->post['body']);
		if (!$body) {
			$this->response->redirect($this->url->link('checkout/success'));
		}
		$response = json_decode($body, true);

		if (!$response) {
			$this->response->redirect($this->url->link('checkout/success'));
		}

		$signature = $this->calcSignature($body, $this->request->post['date']);
		if (strcasecmp($signature, $this->request->post['signature']) !== 0) {
			$this->response->redirect($this->url->link('checkout/success'));
		}

		$data = [];
		if ($response['status'] !== 'SUCCESS') {
			$apiRequest           = $this->getApi();
			$responseData         = $apiRequest->sendStatusRequest($response['merchantPaymentReference']);
			$responseData         = json_decode((string) $responseData["response"], true);
			$data['text_message'] = $this->language->get($responseData['message']);
		} else {
			$data['text_message'] = $this->language->get('text_success_message');
		}

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home', 'language=' . $this->config->get('config_language')),
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_basket'),
			'href' => $this->url->link('checkout/cart', 'language=' . $this->config->get('config_language')),
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_checkout'),
			'href' => $this->url->link('checkout/checkout', 'language=' . $this->config->get('config_language')),
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_success'),
			'href' => $this->url->link('checkout/success', 'language=' . $this->config->get('config_language')),
		];

		$data['continue'] = $this->url->link('common/home', 'language=' . $this->config->get('config_language'));

		$data['column_left']    = $this->load->controller('common/column_left');
		$data['column_right']   = $this->load->controller('common/column_right');
		$data['content_top']    = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer']         = $this->load->controller('common/footer');
		$data['header']         = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('common/success', $data));
	}

	public function callback()
	{

		$rawData = file_get_contents("php://input");
		if ($this->logging) {
			$this->log->write('callback' . ' = ' . $rawData);
		}

		if (empty($_SERVER['HTTP_X_HEADER_SIGNATURE'])) {
			exit();
		}

		$headerSignature = $_SERVER['HTTP_X_HEADER_SIGNATURE'];

		$date      = $_SERVER['HTTP_X_HEADER_DATE'];
		$signature = $this->calcSignature($rawData, $date);
		if (strcasecmp($headerSignature, $signature) !== 0) {
			throw new \Exception('Sign error');
		}

		$json = json_decode($rawData, true);

		$apiRequest   = $this->getApi();
		$responseData = $apiRequest->sendStatusRequest($json['orderData']['merchantPaymentReference']);
		if ($this->logging) {
			$this->log->write('info' . ' = ' . $responseData["response"]);
		}

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['code'] !== 200) {
			throw new \Exception($responseData["message"]);
		}

		$orderData = $json['orderData'];

		$res = explode('.', $orderData['merchantPaymentReference']);

		$merchantPaymentReference = sprintf("%s.%s", $res[0], $res[1]);

		$transaction = [
			'payment_status'                    => $responseData['paymentStatus'],
			'merchant_payment_reference'        => $merchantPaymentReference,
			'merchant_payment_reference_active' => $orderData['merchantPaymentReference'],
			'payu_payment_reference'            => $orderData['payuPaymentReference'],
		];

		$this->updateTransaction($transaction);

		$orderId = intval($res[0]);

		$this->load->model('checkout/order');

		if ($responseData['paymentStatus'] === 'COMPLETE') {
			$this->model_checkout_order->addHistory($orderId, $this->config->get('payment_ypmn_order_status_id'), '', true);
		}

		if ($responseData['paymentStatus'] === 'PAYMENT_AUTHORIZED') {
			$this->model_checkout_order->addHistory($orderId, $this->config->get('payment_ypmn_order_hold_status_id'), '', true);
		}

		if ($responseData['paymentStatus'] === 'REFUND') {
			$this->model_checkout_order->addHistory($orderId, $this->config->get('payment_ypmn_order_refund_status_id'), '', true);
		}

		if ($responseData['paymentStatus'] === 'REVERSED') {
			$this->model_checkout_order->addHistory($orderId, $this->config->get('payment_ypmn_order_refund_status_id'), '', true);
		}
	}

	public function process_order(): void
	{
		$this->load->language('extension/ypmn/payment/ypmn');

		$this->load->model('checkout/order');
		$data['continue'] = $this->url->link('checkout/success');

		$orderInfo = $this->model_checkout_order->getOrder($this->session->data['order_id']);

		try {
			$url = $this->getPaymentLink($orderInfo);
			$this->model_checkout_order->addHistory($this->session->data['order_id'], $this->config->get('config_order_status_id'), '', true);
			$this->cart->clear();
			$this->session->data['order_id'] = null;
		} catch (\Exception $e) {
			$this->session->data['error'] = $e->getMessage();
			$url                          = $this->url->link('checkout/cart', 'language=' . $this->config->get('config_language'));
		}

		$this->response->redirect($url);
	}

	private function getPaymentLink($orderInfo)
	{
		$ypmnPayment = $this->createPayment($orderInfo);

		if ($this->logging) {
			$this->log->write('payment request' . ' = ' . $ypmnPayment->jsonSerialize());
		}

		$apiRequest      = $this->getApi();
		$responseDataRaw = $apiRequest->sendAuthRequest($ypmnPayment);

		if ($this->logging) {
			$this->log->write('payment response' . ' = ' . json_encode($responseDataRaw));
		}

		if ($orderInfo['currency_code'] !== 'RUB') {
			throw new \Exception($this->language->get('text_error_currency'));
		}

		$responseData = json_decode((string) $responseDataRaw["response"], true);

		if (!$responseData) {
			throw new \Exception($this->language->get('text_error_wrong_json'));
		}

		if (isset($responseData['code']) && $responseData['code'] != 200) {
			throw new \Exception($responseData['message']);
		}

		if (!isset($responseData["paymentResult"])) {
			throw new \Exception($this->language->get('text_error_empty_result'));
		}

		$transaction = [
			'order_id'                          => $orderInfo['order_id'],
			'merchant_payment_reference'        => $responseData['merchantPaymentReference'],
			'merchant_payment_reference_active' => $responseData['merchantPaymentReference'],
			'url'                               => $responseData["paymentResult"]['url'],
			'payment_status'                    => $responseData['paymentResult']['payuResponseCode'],
			'payment_method'                    => PaymentMethods::CCVISAMC,
			'amount'                            => $responseData['amount'],
			'products'                          => json_encode($ypmnPayment->getProductsArray()),
			'sandbox'                           => $this->config->get('payment_ypmn_test_mode'),
		];

		if ($responseData['payuPaymentReference'] !== 'NOT_YET_REGISTERED') {
			$transaction['payu_payment_reference'] = $responseData['payuPaymentReference'];
		}

		$this->insertTransaction($transaction);
		return $responseData["paymentResult"]['url'];
	}

	private function createPayment($order)
	{
		$ypmnPayment = new Payment();
		$ypmnPayment->setCurrency('RUB');
		$products = $this->getOrderProducts($order);
		foreach ($products as $product) {
			$ypmnPayment->addProduct($product);
		}
		$merchantPaymentReference = sprintf("%s.%s", $order['order_id'], time());
		$ypmnPayment->setMerchantPaymentReference($merchantPaymentReference);
		$ypmnPayment->setReturnUrl($this->url->link('extension/ypmn/payment/ypmn.result'));

		$client = $this->getClient($order);
		$ypmnPayment->setClient($client);

		$authorization = $this->getAuthorization();
		$ypmnPayment->setAuthorization($authorization);
		return $ypmnPayment;
	}

	protected function getAuthorization()
	{
		$paymentMethodType = $this->config->get('payment_ypmn_payment_method');
		$isPaymentPage     = false;

		if ($paymentMethodType === '') {
			$paymentMethodType = null;
		}

		if ($paymentMethodType === PaymentMethods::CCVISAMC) {
			$isPaymentPage = true;
		}

		$authorization = new Authorization($paymentMethodType, $isPaymentPage);
		return $authorization;
	}

	protected function getMerchant()
	{
		$secretKey = html_entity_decode($this->config->get('payment_ypmn_secret_key'));
		$merchant  = new Merchant(
			$this->config->get('payment_ypmn_merchant_code'),
			$secretKey
		);
		return $merchant;
	}

	protected function getApi()
	{
		$merchant = $this->getMerchant();

		$apiRequest = new ApiRequest($merchant);

		if ($this->config->get('payment_ypmn_test_mode')) {
			$apiRequest->setSandboxMode();
		}
		return $apiRequest;
	}

	protected function getClient($order)
	{
		$billing = $this->getBilling($order);
		$client  = new Client();
		$client->setBilling($billing);
		$client->setCurrentClientIp();
		$client->setCurrentClientTime();
		return $client;
	}

	protected function getBilling($order)
	{
		$billing = new Billing();
		$billing->setFirstName($order['firstname']);
		$billing->setLastName($order['lastname']);
		$billing->setPhone($order['telephone']);
		$billing->setEmail($order['email']);
		$billing->setCountryCode('RU');
		return $billing;
	}

	protected function getOrderProducts($order)
	{
		$amount = $this->currency->format($order['total'], $order['currency_code'], $order['currency_value'], false);
		if (!$this->config->get('payment_ypmn_product_list')) {
			$item = [
				"name"      => $this->language->get('text_product'),
				"sku"       => 'product',
				"quantity"  => 1,
				"unitPrice" => floatval($amount),
				"vat"       => 1,
			];
			return [new Product($item)];
		}

		$products = [];
		$query    = $this->db->query("
			SELECT op.* FROM " . DB_PREFIX . "order_product as op
			WHERE op.order_id = '" . $order['order_id'] . "'
			");

		$taxId = $this->config->get('payment_ypmn_product_vat');

		foreach ($query->rows as $key => $product) {
			if ($product['price'] == 0) {
				continue;
			}

			$price = $product['price'];
			if ($this->config->get('total_tax_status')) {
				$price += $product['tax'];
			}

			$item = [
				"name"      => htmlspecialchars_decode($product['name']),
				"sku"       => sprintf('%d.%s', $key, strval($product['model'])),
				"quantity"  => intval($product['quantity']),
				"unitPrice" => round($price, 2),
				"vat"       => intval($taxId),
			];

			$products[] = new Product($item);
		}
		if (version_compare(VERSION, '4.1.0.0') == -1) {
			$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_voucher WHERE order_id = '" . $order['order_id'] . "'");
			foreach ($query->rows as $key => $product) {
				$item = [
					"name"      => $product['description'],
					"sku"       => sprintf('%d.%s', $key, strval($product['voucher_id'])),
					"quantity"  => 1,
					"unitPrice" => round($product['amount'], 2),
					"vat"       => intval($taxId),
				];

				$products[] = new Product($item);
			}
		}

		$shippingCost = 0;
		if (!empty($order['shipping_method']['cost'])) {
			$shippingCost = $this->tax->calculate($order['shipping_method']['cost'], $order['shipping_method']['tax_class_id'], $this->config->get('total_tax_status'));
		}
		if ($shippingCost > 0) {
			$taxId = $this->config->get('payment_ypmn_delivery_vat');
			$item  = [
				"name"      => $order['shipping_method']['name'],
				"sku"       => 'shipping',
				"quantity"  => 1,
				"unitPrice" => round($shippingCost, 2),
				"vat"       => intval($taxId),
			];

			$products[] = new Product($item);
		}
		return $products;
	}

	private function insertTransaction($data)
	{
		$data = array_intersect_key($data, array_flip([
			'merchant_payment_reference',
			'merchant_payment_reference_active',
			'order_id',
			'payu_payment_reference',
			'amount',
			'url',
			'payment_status',
			'payment_method',
			'amount_refunded',
			'date',
			'products',
		]));
		$db          = $this->db;
		$escapedData = array_map(function ($item) use ($db) {
			return '"' . $db->escape($item) . '"';
		}, $data);

		$this->db->query("REPLACE " . DB_PREFIX . "ypmn (" . implode(',', array_keys($escapedData)) . ") VALUES (" . implode(',', $escapedData) . ")");
	}

	private function updateTransaction($data)
	{
		$data = array_intersect_key($data, array_flip([
			'merchant_payment_reference',
			'merchant_payment_reference_active',
			'order_id',
			'payu_payment_reference',
			'amount',
			'url',
			'payment_status',
			'payment_method',
			'amount_refunded',
			'date',
			'products',
		]));
		$db          = $this->db;
		$escapedData = array_map(function ($key, $item) use ($db) {
			return '`' . $key . '`="' . $db->escape($item) . '"';
		}, array_keys($data), $data);

		$this->db->query("UPDATE " . DB_PREFIX . "ypmn set " . implode(',', $escapedData) . " where merchant_payment_reference='" . $this->db->escape($data['merchant_payment_reference']) . "'");
	}

	protected function calcSignature($input, $date)
	{
		$urlParts         = parse_url($_SERVER['REQUEST_URI']);
		$urlHashableParts = 'POST' . $urlParts['path'];
		if (isset($urlParts['query'])) {
			$urlHashableParts .= $urlParts['query'];
		}
		$hashableString = $this->config->get('payment_ypmn_merchant_code') . $date . $urlHashableParts . md5($input);
		$secretKey      = html_entity_decode($this->config->get('payment_ypmn_secret_key'));
		return hash_hmac('sha256', $hashableString, $secretKey);
	}

}
