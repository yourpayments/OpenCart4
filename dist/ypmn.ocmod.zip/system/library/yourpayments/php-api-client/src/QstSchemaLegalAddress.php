<?php declare(strict_types=1);

namespace Ypmn;

/**
 * Юридический адреса продавца в анкете
 **/
class QstSchemaLegalAddress extends QstSchemaAddressAbstract
{
}
