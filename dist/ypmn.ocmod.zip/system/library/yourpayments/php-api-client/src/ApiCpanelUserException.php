<?php

declare(strict_types=1);

namespace Ypmn;

use Exception;

class ApiCpanelUserException extends Exception
{
}
