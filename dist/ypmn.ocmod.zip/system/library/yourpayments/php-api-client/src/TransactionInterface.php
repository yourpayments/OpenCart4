<?php declare(strict_types=1);

namespace Ypmn;

interface TransactionInterface
{

}
