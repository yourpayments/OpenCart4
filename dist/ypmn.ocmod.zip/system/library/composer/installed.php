<?php return array (
  'root' => 
  array (
    'pretty_version' => '1.0.0+no-version-set',
    'version' => '1.0.0.0',
    'aliases' => 
    array (
    ),
    'reference' => NULL,
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => '1.0.0+no-version-set',
      'version' => '1.0.0.0',
      'aliases' => 
      array (
      ),
      'reference' => NULL,
    ),
    'yourpayments/php-api-client' => 
    array (
      'pretty_version' => 'v1.7.8',
      'version' => '1.7.8.0',
      'aliases' => 
      array (
      ),
      'reference' => '7861e60905a76fb921238b7b1a6c5f39bb68a273',
    ),
  ),
);
