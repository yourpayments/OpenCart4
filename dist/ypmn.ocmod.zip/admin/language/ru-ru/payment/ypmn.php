<?php
$_['heading_title'] = 'Твои платежи';

// Text
$_['text_title']     = 'Твои платежи';
$_['text_extension'] = 'Расширения';
$_['text_payment']   = 'Оплата';
$_['text_success']   = 'Успех: Настройки сохранены!';
$_['text_edit']      = 'Редактирование настроек';
$_['text_ypmn']      = '<a onclick="window.open(\'https://ypmn.ru\');"><img src="../extension/ypmn/admin/view/image/payment/ypmn.svg" alt="Твои платежи" title="Твои платежи" style="border: 1px solid #EEEEEE;height:38px;background:#000;padding:0 5px;" /></a>';

$_['text_paymentname'] = 'Твои платежи';

$_['text_ypmn_menu'] = 'Твои платежи';

// Entry
$_['entry_status']                 = 'Статус';
$_['entry_logging']                = 'Логгирование';
$_['entry_paymentname']            = 'Название оплаты';
$_['entry_merchant_code']          = 'Код мерчанта';
$_['entry_secret_key']             = 'Секретный ключ';
$_['entry_product_list']           = 'Передавать список товаров попродуктно';
$_['entry_payment_method']         = 'Способ оплаты';
$_['entry_product_vat']            = 'НДС на товары';
$_['entry_delivery_vat']           = 'НДС на доставку';
$_['entry_order_status_id']        = 'Статус заказа при оплате';
$_['entry_order_hold_status_id']   = 'Статус заказа при авторизации оплаты';
$_['entry_order_refund_status_id'] = 'Статус заказа при возврате';
$_['entry_sort_order']             = 'Сортировка';
$_['entry_callback_link']          = 'Адрес для получения вебхуков (для обновления статусов)';
$_['entry_test_mode']              = 'Режим песочницы (для тестов)';

$_['text_callback_desc']  = 'Этот адрес надо указать в <a target="_blank" href="https://secure.ypmn.ru/cpanel/?utm_source=opencart4_module">личном кабинете</a> или передать менеджеру <a target="_blank" href="https://ypmn.ru/?utm_source=opencart4_module">«Твои платежи»</a>.<br>
<br>
Эта и другая документация доступна на официальном сайте: <a target="_blank" href="https://ypmn.ru/ru/documentation/?utm_source=opencart4_module#tag/webhooks">ypmn.ru/ru/documentation/</a><br>
<br>
Наши контакты для связи и поддержки: <a target="_blank" href="https://ypmn.ru/ru/company-about/">ypmn.ru/ru/company-about/</a><br>
<br>
Спасибо, что выбрали <a target="_blank" href="https://ypmn.ru/ru/?utm_source=opencart4_module">«Твои платежи»</a>!';
$_['text_paymentname_desc'] = 'Заголовок, который видит пользователь в процессе оформления заказа.';
$_['text_merchant_code_desc'] = 'Введите код мерчанта (его можно получить у менеджера или в личном кабинете)';
$_['text_secret_key_desc'] = 'Введите секретный ключ (его можно получить у менеджера или в личном кабинете)';
$_['text_test_mode_desc'] = 'Интеграционный сервер SANDBOX.YPMN.RU';
$_['text_product_list_desc'] = 'Отправляйте товары для подробных отчётов и чеков';
$_['text_product_vat_desc'] = 'Выберите налог на товар';
$_['text_delivery_vat_desc'] = 'Выберите налог на доставку';
$_['text_log_path']       = 'Путь до файл с логами:';

$_['text_settings']  = 'Настройки';

$_['text_vat_0']  = 'НДС 0%';
$_['text_vat_10'] = 'НДС 10%';
$_['text_vat_20'] = 'НДС 20%';
$_['text_vat_5']  = 'НДС 5%';
$_['text_vat_7']  = 'НДС 7%';

$_['text_payment_method_page'] ="Выбор на платежной странице";
$_['text_payment_method_ccvisamc'] ="Оплата картой";
$_['text_payment_method_faster_payments'] ="Оплата по СБП";
$_['text_payment_method_bnpl'] ="Оплата в рассрочку";
$_['text_payment_method_sberpay'] ="Оплата SberPay";
$_['text_payment_method_alfapay'] ="Оплата Alfa Pay";
$_['text_payment_method_tpay'] ="Оплата T-Pay";
$_['text_payment_method_mirpay'] ="Оплата MirPay";
$_['text_payment_method_som'] ="Оплата зарубежной картой";

$_['column_order_id'] = 'Номер заказа';
$_['column_status']   = 'Статус';
$_['column_total']    = 'Сумма';
$_['column_action']   = 'Информация';
$_['column_date']     = 'Дата';
$_['entry_order_id']  = 'Номер заказа';
$_['text_info']       = 'Информация';

$_['text_transaction']           = 'Транзакция';
$_['text_column_merchant_payment_reference']     = 'Id транзакции';
$_['text_column_order_id']       = 'Id заказа';
$_['text_column_payment_status'] = 'Статус';
$_['text_column_amount']         = 'Cумма';
$_['text_payu_payment_reference']     = 'PayuPaymentReference';
$_['text_column_date']           = 'Дата';

$_['text_wait_message']   = 'Статус обновится в ближайшее время';
$_['tab_info']       = 'Информация';
$_['tab_operations'] = 'Операции';


$_['button_refund']       = 'Возврат';
$_['button_capture']       = 'Завершить';
$_['button_check_status']  = 'Запросить статус';

$_['text_operation_success'] = 'Запрос принят, статус транзакции обновится в ближайшее время';

$_['text_list_transactions'] = 'Список транзакций';

$_['text_product'] = 'Товар';


$_['text_capture_column_name'] = 'Название';
$_['text_capture_column_quantity'] = 'Количество';
$_['text_capture_column_price'] = 'Цена';

$_['text_refund_column_name'] = 'Название';
$_['text_refund_column_quantity'] = 'Количество';
$_['text_refund_column_price'] = 'Цена';
$_['text_status_changed'] = 'Статус транзакции изменён на ';

$_['text_check_status_notice'] = 'Для транзакций, где способ платежа выбирается на платежной странице, обновление статуса доступно только после стадии PAYMENT_AUTORIZED ';