<?php
$_['heading_title'] = 'Your payments';

// Text
$_['text_title']     = 'Your payments';
$_['text_extension'] = 'Extensions';
$_['text_payment']   = 'Payment';
$_['text_success']   = 'Success: Settings saved!';
$_['text_edit']      = 'Settings edit';
$_['text_ypmn']      = '<a onclick="window.open(\'https://ypmn.ru\');"><img src="../extension/ypmn/admin/view/image/payment/ypmn.svg" alt="Your payments" title="Your payments" style="border: 1px solid #EEEEEE;height:38px;background:#000;padding:0 5px;" /></a>';

$_['text_paymentname'] = 'Your payments';

$_['text_ypmn_menu'] = 'Your payments';

// Entry
$_['entry_status']                 = 'Status';
$_['entry_logging']                = 'Logging';
$_['entry_paymentname']            = 'Payment name';
$_['entry_merchant_code']          = 'Merchant code';
$_['entry_secret_key']             = 'Secret key';
$_['entry_product_list']           = 'Send products';
$_['entry_product_vat']            = 'Product VAT';
$_['entry_delivery_vat']           = 'Delivery VAT';
$_['entry_order_status_id']        = 'Payed status';
$_['entry_order_hold_status_id']   = 'Hold status';
$_['entry_order_refund_status_id'] = 'Refund status';
$_['entry_sort_order']             = 'Sort';
$_['entry_callback_link']          = 'Callback';
$_['entry_test_mode']              = 'Sandbox mode';
$_['entry_payment_method']         = 'Payment method';

$_['text_callback_desc']  = 'This address must be specified in the <a target="_blank" href="https://secure.ypmn.ru/cpanel/?utm_source=opencart4_module">personal account</a> or passed to the <a target="_blank" href="https://ypmn.ru/?utm_source=opencart4_module">“Your Payments”</a> manager.<br>
<br>
This and other documentation is available on the official website: <a target="_blank" href="https://ypmn.ru/ru/documentation/?utm_source=opencart4_module#tag/webhooks">ypmn.ru/ru/documentation/</a><br>
<br>
Our contact information and support: <a target="_blank" href="https://ypmn.ru/ru/company-about/">ypmn.ru/ru/company-about/</a><br>
<br>
Thank you for choosing <a target="_blank" href="https://ypmn.ru/ru/?utm_source=opencart4_module">Your Payments</a>!';
$_['text_paymentname_desc'] = '';
$_['text_merchant_code_desc'] = '';
$_['text_secret_key_desc'] = '';
$_['text_test_mode_desc'] = '';
$_['text_product_list_desc'] = '';
$_['text_product_vat_desc'] = '';
$_['text_delivery_vat_desc'] = '';
$_['text_log_path']       = 'Log path:';

$_['text_settings']  = 'Settings';

$_['text_vat_0']  = 'VAT 0%';
$_['text_vat_10'] = 'VAT 10%';
$_['text_vat_20'] = 'VAT 20%';
$_['text_vat_5']  = 'VAT 5%';
$_['text_vat_7']  = 'VAT 7%';

$_['column_order_id'] = 'Order number';
$_['column_status']   = 'Status';
$_['column_total']    = 'Amount';
$_['column_action']   = 'Info';
$_['column_date']     = 'Date';
$_['entry_order_id']  = 'Order number';
$_['text_info']       = 'Info';
$_['text_wait_message'] = 'Waiting';

$_['text_payment_method_page'] ="Select on payment page";
$_['text_payment_method_ccvisamc'] ="by card";
$_['text_payment_method_faster_payments'] ="faster payments";
$_['text_payment_method_bnpl'] ="bnpl";
$_['text_payment_method_sberpay'] ="SberPay";
$_['text_payment_method_alfapay'] ="Alfa Pay";
$_['text_payment_method_tpay'] ="T-Pay";
$_['text_payment_method_mirpay'] ="MirPay";
$_['text_payment_method_som'] ="Foreign card";

$_['text_check_status_notice'] = 'Status check avaiable after PAYMENT_AUTORIZED stage';

$_['text_transaction']           = 'Transaction';
$_['text_column_merchant_payment_reference']     = 'Transaction id';
$_['text_column_order_id']       = 'Order id';
$_['text_column_payment_status'] = 'Status';
$_['text_column_amount']         = 'Amount';
$_['text_payu_payment_reference']     = 'PayuPaymentReference';
$_['text_column_date']           = 'Date';

$_['tab_info']       = 'Info';
$_['tab_operations'] = 'Operations';


$_['button_refund']       = 'Refund';
$_['button_capture']       = 'Confirm';
$_['button_check_status']  = 'Update status';

$_['text_operation_success'] = 'Action in progress, please wait';

$_['text_list_transactions'] = 'Transaction list';

$_['text_product'] = 'Product';


$_['text_capture_column_name'] = 'Name';
$_['text_capture_column_quantity'] = 'Quantity';
$_['text_capture_column_price'] = 'Price';

$_['text_refund_column_name'] = 'Name';
$_['text_refund_column_quantity'] = 'Quantity';
$_['text_refund_column_price'] = 'Price';
$_['text_status_changed'] = 'Transaction status changed ';
