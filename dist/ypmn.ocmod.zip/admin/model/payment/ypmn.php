<?php
namespace Opencart\Admin\Model\Extension\Ypmn\Payment;

use Opencart\System\Engine\Model;

class Ypmn extends Model {

	public function getMethod(): array
	{

		$this->load->language('extension/ypmn/payment/ypmn');


			$method_data = array(
				'code'       => 'ypmn',
				'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => $this->config->get('payment_ypmn_sort_order')
			);


		return $method_data;
	}

	public function getTotalTransactions($data = array()) {
		$sql = "SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "ypmn`";


		if (!empty($data['filter_order_id'])) {
			$sql .= " WHERE order_id = '" . (int)$data['filter_order_id'] . "'";
		}

		$query = $this->db->query($sql);

		return $query->row['total'];
	}

	public function getTransactions($data = array())
	{
		$sql = "SELECT o.* FROM `" . DB_PREFIX . "ypmn` o";

		if (!empty($data['filter_order_id'])) {
			$sql .= " WHERE o.order_id= '" . (int)$data['filter_order_id'] . "'";
		}

		$sort_data = array(
			'o.order_id',
			'o.amount',
			'o.payment_status',
			'o.date',
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY o.order_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}


		$query = $this->db->query($sql);

		return $query->rows;
	}
}